package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private WebView mwebView;
    private WebSettings mwebSettings;

    Button btnRefresh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mwebView = (WebView) findViewById(R.id.webview);
        btnRefresh = (Button) findViewById(R.id.btnRefresh);
        mwebView.setWebViewClient(new WebViewClient());
        mwebSettings = mwebView.getSettings();
        mwebSettings.setJavaScriptEnabled(true);
        mwebSettings.setSupportMultipleWindows(false);
        mwebSettings.setJavaScriptCanOpenWindowsAutomatically(false);
        mwebSettings.setLoadWithOverviewMode(true);
        mwebSettings.setUseWideViewPort(true);
        mwebSettings.setSupportZoom(false);
        mwebSettings.setBuiltInZoomControls(false);
        mwebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        mwebSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        mwebSettings.setDomStorageEnabled(true);

        mwebView.loadUrl("http://june5228.dothome.co.kr/index.html");

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mwebView.reload();
            }
        });
    }
}